let y = 102;

function setup() {
    createCanvas(720,360);
}
function draw(){
    background(y)
    for(let i = 0;i<500;i++) {
    y=color (random(150),random(150),0)
    console.log(i)  
    }
  
}

